using System.Collections.Generic;
using UnityEngine;

public class Tab : MonoBehaviour {

    public string stringVar1;
    public string stringVar2;
    public string stringVar3;
    public string stringVar4;
    public string stringVar5;

    public int intVar1;
    public int intVar2;
    public int intVar3;
    public int intVar4;
    public int intVar5;

    public bool boolVar1;
    public bool boolVar2;
    public bool boolVar3;
    public bool boolVar4;
    public bool boolVar5;

    public List<string> listVar1;
    public List<string> listVar2;
    public List<string> listVar3;
    public List<string> listVar4;
    public List<string> listVar5;

    public int[] arrayVar1;
    public int[] arrayVar2;
    public int[] arrayVar3;
    public int[] arrayVar4;
    public int[] arrayVar5;

    [HideInInspector] public int toolbarTop;
    public int toolbarBottom;
    public string currentTab;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
